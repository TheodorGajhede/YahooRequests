from distutils.core import setup
setup(
    name='YahooRequests',
    packages=['YahooRequests'],
    version='0.1',
    license='MIT',
    description='A simple Python library for getting stock prices and company names from Yahoo Finance.',
    author='Theodor Gajhede',
    author_email='theodorgajhede@gmail.com',
    url='https://github.com/TheodorGajhede/YahooRequests',
    download_url='https://github.com/TheodorGajhede/YahooRequests/archive/refs/tags/TEST.tar.gz',
    keywords=['Stocks', 'Ticker', 'Yahoo'],
    install_requires=[
          'requests'
          ],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',      # Define that your audience are developers
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: MIT License',   # Again, pick a license
        'Programming Language :: Python :: 3',      # Specify which pyhton versions that you want to support
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.8',
            ],
)
